// Copyright (c) 2025, jignasha chavda and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Guest House", {
// 	refresh(frm) {

// 	},
// });
